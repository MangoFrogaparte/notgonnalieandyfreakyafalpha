# Discord Server https://discord.gg/tf673CkW
# Untitled Proxy! PLEASE STAR!!!!
A fast proxy that is lightweight and has efficency in mind!
# How to host?
Currently it is static(Without a bare server) running on my own special bare server!
So it would work if you forked this repo and just did a static host such as, Vercel, github pages, netlify, etc Note: It has to be ON a webserver not local or else it will not work
# BACKEND!!!
The backend is here and it runs on cloudflare workers https://github.com/MaxWeichers/bare-server-workers
